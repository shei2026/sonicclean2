import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
    debugShowCheckedModeBanner: false, home: SonicClean2()));

class SonicClean2 extends StatefulWidget {
  const SonicClean2({super.key});
  @override
  State<SonicClean2> createState() => _S();
}

class _S extends State<SonicClean2> {
  final _p = AudioPlayer();
  Timer? _t;
  bool run = false;
  int left = 0;
  double secs = 30;
  int mode = 0; // 0 agua, 1 polvo, 2 profundo

  Uint8List wav() {
    const sr = 44100, dur = 4;
    final n = sr * dur, len = n * 2;
    final b = ByteData(44 + len);
    void s(int o, String x) {
      for (var i = 0; i < x.length; i++) b.setUint8(o + i, x.codeUnitAt(i));
    }
    s(0, 'RIFF'); b.setUint32(4, 36 + len, Endian.little); s(8, 'WAVE');
    s(12, 'fmt '); b.setUint32(16, 16, Endian.little);
    b.setUint16(20, 1, Endian.little); b.setUint16(22, 1, Endian.little);
    b.setUint32(24, sr, Endian.little); b.setUint32(28, sr * 2, Endian.little);
    b.setUint16(32, 2, Endian.little); b.setUint16(34, 16, Endian.little);
    s(36, 'data'); b.setUint32(40, len, Endian.little);
    double ph = 0;
    for (var i = 0; i < n; i++) {
      final t = i / sr;
      double f = mode == 2 ? 80 + 320 * (0.5 + 0.5 * sin(2 * pi * t / dur)) : (mode == 1 ? 220 : 165);
      ph += 2 * pi * f / sr;
      double v = sin(ph);
      if (mode == 1) v = v >= 0 ? 1 : -1;
      if (mode == 1 && ((t * 8).floor() % 2 == 1)) v = 0;
      b.setInt16(44 + i * 2, (v * 30000).round(), Endian.little);
    }
    return b.buffer.asUint8List();
  }

  Future<void> start() async {
    await _p.setReleaseMode(ReleaseMode.loop);
    await _p.play(BytesSource(wav()));
    setState(() { run = true; left = secs.round(); });
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => left--);
      if (left <= 0) stop();
    });
  }

  Future<void> stop() async {
    _t?.cancel();
    await _p.stop();
    if (mounted) setState(() => run = false);
  }

  @override
  void dispose() { _t?.cancel(); _p.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: const Color(0xFF06121F),
        appBar: AppBar(
            title: const Text('🔊 SonicClean2'),
            centerTitle: true,
            backgroundColor: const Color(0xFF0D2238),
            foregroundColor: Colors.white),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('💧 Agua')),
                ButtonSegment(value: 1, label: Text('🌫️ Polvo')),
                ButtonSegment(value: 2, label: Text('🌊 Profundo')),
              ],
              selected: {mode},
              onSelectionChanged: run ? null : (v) => setState(() => mode = v.first),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: 180, height: 180,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    shape: const CircleBorder(),
                    backgroundColor: run ? Colors.red : const Color(0xFF00B4FF)),
                onPressed: run ? stop : start,
                child: Text(run ? 'DETENER' : 'INICIAR',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
            Text(run ? 'Limpiando… ${left}s' : 'Listo',
                style: const TextStyle(color: Colors.white)),
            Slider(value: secs, min: 10, max: 120, divisions: 22,
                label: '${secs.round()} s',
                onChanged: run ? null : (v) => setState(() => secs = v)),
          ]),
        ),
      );
}
